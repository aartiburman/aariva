<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Users;
use App\Models\Wishlist;
use App\Models\Banner;
use App\Models\Product;
use App\Helpers\ImageHelper;
use App\Helpers\PriceHelper;
use Carbon\Carbon;



class WishlistController extends Controller
{



public function add_to_wishlist(Request $request)
{
    /* -------------------------
       VALIDATION
    ------------------------- */
    $request->validate([
        'user_id'    => 'required|exists:users,id',
        'product_id' => 'required|exists:products,id',
        'qty'        => 'nullable|numeric|min:1',
        'color'      => 'nullable|string',
        'size'       => 'nullable|string',
        'action'     => 'required|in:0,1',
    ]);

    /* -------------------------
       FETCH PRODUCT + VARIANT + COUPON
    ------------------------- */
    $product = Product::with([
        'variants' => function ($q) {
            $q->orderBy('id', 'asc'); // always first variant
        },
        'coupon'
    ])->find($request->product_id);

    if (!$product || $product->variants->isEmpty()) {
        return response()->json([
            'status'  => false,
            'message' => 'Product or variant not found'
        ], 404);
    }

    $variant = $product->variants->first();

    /* -------------------------
       PRICE CALCULATION
    ------------------------- */
    $originalPrice = (float) $variant->price;

    $finalPrice = PriceHelper::applyDiscount(
        $originalPrice,
        $variant->discount_type,
        $variant->discount_value
    );

    /* -------------------------
       APPLY COUPON (IF VALID)
    ------------------------- */
    $today = Carbon::now();

    if (
        $product->coupon &&
        $product->coupon->status == 1 &&
        $product->coupon->valid_from <= $today &&
        $product->coupon->valid_until >= $today &&
        (
            is_null($product->coupon->max_uses) ||
            $product->coupon->used_count < $product->coupon->max_uses
        )
    ) {
        $finalPrice = PriceHelper::applyDiscount(
            $finalPrice,
            $product->coupon->type,
            $product->coupon->value
        );
    }

    /* -------------------------
       FIRST VARIANT IMAGE (RAW NAME)
    ------------------------- */
    $img = null;

    if (!empty($variant->image)) {
        if (str_starts_with($variant->image, '[')) {
            $img = json_decode($variant->image, true)[0] ?? null;
        } elseif (str_contains($variant->image, ',')) {
            $img = trim(explode(',', $variant->image)[0]);
        } else {
            $img = $variant->image;
        }
    }

    /* -------------------------
       ADD / UPDATE WISHLIST
    ------------------------- */
    if ($request->action == 1) {

        Wishlist::updateOrCreate(
            [
                'user_id'    => $request->user_id,
                'product_id' => $product->id,
            ],
            [
                'variant_id'  => $variant->id,
                'qty'         => $request->qty ?? 1,
                'color'       => $request->color,
                'size'        => $request->size,
                'price'       => $originalPrice,
                'final_price' => $finalPrice,
                'image'       => $img,
            ]
        );

        return response()->json([
            'status'  => true,
            'message' => 'Item added to wishlist successfully'
        ]);
    }

    /* -------------------------
       REMOVE FROM WISHLIST
    ------------------------- */
    Wishlist::where('user_id', $request->user_id)
        ->where('product_id', $product->id)
        ->delete();

    return response()->json([
        'status'  => true,
        'message' => 'Item removed from wishlist successfully'
    ]);
}




    public function get_wishlist(Request $request)
    {
        $request->validate([
            'user_id'  => 'required|exists:users,id',
            'per_page' => 'nullable|integer|min:1|max:100',
        ]);

        $userId  = $request->user_id;
        $perPage = $request->input('per_page', 12);

        $paginator = Wishlist::where('user_id', $userId)
            ->leftJoin('products', 'wishlists.product_id', '=', 'products.id')
            ->select('wishlists.*', 'products.name as product_name', 'products.slug as product_slug', 'products.short_description')
            ->paginate($perPage);

        foreach ($paginator->items() as $item) {
            $item->image = ImageHelper::getProductImage($item->image);
        }

        $banner = Banner::where('position', 'wishlist')->first();
        $bannerImage = null;
        if ($banner) {
            $img = json_decode($banner->image, true);
            $bannerImage = ImageHelper::getBannerImage($img[0] ?? '');
        }

        return response()->json([
            'status'     => true,
            'message'    => 'Wishlist fetched successfully',
            'banner'     => $bannerImage,
            'count'      => $paginator->total(),
             'data'       => $paginator->items(),
            'pagination' => [
                'current_page'  => $paginator->currentPage(),
                'last_page'     => $paginator->lastPage(),
                'per_page'      => $paginator->perPage(),
                'total'         => $paginator->total(),
                'next_page_url' => $paginator->nextPageUrl(),
                'prev_page_url' => $paginator->previousPageUrl(),
            ],
           
        ]);
    }
}
