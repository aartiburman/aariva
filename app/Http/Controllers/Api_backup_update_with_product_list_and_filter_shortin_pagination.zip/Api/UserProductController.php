<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Product;
use App\Models\Banner;
use App\Models\Coupon;
use App\Helpers\ImageHelper;
use App\Helpers\PriceHelper;
use Carbon\Carbon;
use App\Models\ProductVariant;
use App\Models\Brand;
use  Illuminate\Support\Facades\DB;
use App\Models\Category;
use App\Models\SubCategory;
use App\Models\ChildCategory;
use Stichoza\GoogleTranslate\GoogleTranslate;


class UserProductController extends Controller
{
   public function get_product_detail(Request $request)
{
    $request->validate([
        'product_id' => 'required|exists:products,id',
    ]);

    $product = Product::with([
        'variants',
        'vendor:id,name',
        'category:id,name',
        'subCategory:id,name',
        'childCategory:id,name',
        'brand:id,name',
        'coupon'
    ])->find($request->product_id);

    if (!$product) {
        return response()->json([
            'status'  => false,
            'message' => 'Product not found'
        ], 404);
    }

    /* -------------------------
       COUPONS
    ------------------------- */
    $coupon_ids   = json_decode($product->coupon_id, true) ?? [];
    $coupa_names  = [];

    if (!empty($coupon_ids)) {
        $coupons = Coupon::whereIn('id', $coupon_ids)->get();
        foreach ($coupons as $c) {
            $coupa_names[] = $c->code;
        }
    }

    $product->coupons    = $coupa_names;
    $product->coupon_id  = $coupon_ids;
    $product->product_in = json_decode($product->product_in, true) ?? [];

    /* -------------------------
       NAMES
    ------------------------- */
    $product->vendor_name         = $product->vendor->name ?? null;
    $product->category_name       = $product->category->name ?? null;
    $product->sub_category_name   = $product->subCategory->name ?? null;
    $product->child_category_name = $product->childCategory->name ?? null;
    $product->brand_name          = $product->brand->name ?? null;

    unset(
        $product->vendor,
        $product->category,
        $product->subCategory,
        $product->childCategory,
        $product->brand
    );

    /* -------------------------
       COUPON VALIDATION
    ------------------------- */
    $today  = Carbon::now();
    $coupon = null;

    if (
        $product->coupon &&
        $product->coupon->status == 1 &&
        $product->coupon->valid_from <= $today &&
        $product->coupon->valid_until >= $today &&
        (
            is_null($product->coupon->max_uses) ||
            $product->coupon->used_count < $product->coupon->max_uses
        )
    ) {
        $coupon = [
            'code'        => $product->coupon->code,
            'type'        => $product->coupon->type,
            'value'       => $product->coupon->value,
            'discount'    => $product->coupon->type === 'percent'
                ? $product->coupon->value . '% OFF'
                : '₹' . $product->coupon->value . ' OFF',
            'valid_from'  => $product->coupon->valid_from,
            'valid_until' => $product->coupon->valid_until,
        ];
    }

    $product->coupon = $coupon;

    /* -------------------------
       VARIANTS
    ------------------------- */
    $allColors = [];
    $allSizes  = [];

    foreach ($product->variants as $variant) {

        $variant->original_price = $variant->price;

        $price = PriceHelper::applyDiscount(
            $variant->price,
            $variant->discount_type,
            $variant->discount_value
        );

        if ($coupon) {
            $price = PriceHelper::applyDiscount(
                $price,
                $coupon['type'],
                $coupon['value']
            );
        }

        $variant->final_price = $price;

        if ($variant->color) {
            $allColors[] = $variant->color;
        }

        $sizes = json_decode($variant->size, true);
        if (is_array($sizes)) {
            $allSizes = array_merge($allSizes, $sizes);
        }

        $images = [];
        if ($variant->image) {
            if (str_starts_with($variant->image, '[')) {
                foreach (json_decode($variant->image, true) ?? [] as $img) {
                    $images[] = ImageHelper::getProductImage($img);
                }
            } elseif (str_contains($variant->image, ',')) {
                foreach (explode(',', $variant->image) as $img) {
                    $images[] = ImageHelper::getProductImage(trim($img));
                }
            } else {
                $images[] = ImageHelper::getProductImage($variant->image);
            }
        }

        $variant->images = $images;
        $variant->size   = $sizes ?? [];

        unset($variant->image);
    }

    $product->colors = array_values(array_unique($allColors));
    $product->sizes  = array_values(array_unique($allSizes));

    $product->currency = ($request->lang === 'ar')
        ? ImageHelper::getDirhamImage()
        : ImageHelper::getINRImage();

    $product->rating = 4.5;
    $product->review_count = '3.5k';

    if ($product->variants->isNotEmpty()) {
        $v = $product->variants->first();
        $product->first_image = $v->images[0] ?? null;
        $product->base_price  = $v->original_price;
        $product->final_price = $v->final_price;
    }

    /* -------------------------
       RELATED PRODUCTS
    ------------------------- */
    $lang = $request->lang;

    $relatedProducts = Product::with(['variants:id,product_id,price,image'])
        ->where('id', '!=', $product->id)
        ->where('status', 1)
        ->where(function ($q) use ($product) {
            if ($product->child_category_id) {
                $q->where('child_category_id', $product->child_category_id);
            } elseif ($product->subcategory_id) {
                $q->where('subcategory_id', $product->subcategory_id);
            } else {
                $q->where('category_id', $product->category_id);
            }
        })
        ->latest()
        ->limit(8)
        ->get()
        ->map(function ($item) use ($lang) {

            $variant = $item->variants->first();
            $image = null;

            if ($variant && $variant->image) {
                $image = str_contains($variant->image, ',')
                    ? explode(',', $variant->image)[0]
                    : $variant->image;
            }

            return [
                'id'            => $item->id,
                'name'          => $item->name,
                'price'         => $variant->price ?? null,
                'currency'      => $lang === 'ar'
                    ? ImageHelper::getDirhamImage()
                    : ImageHelper::getINRImage(),
                'rating'        => 4.5,
                'review_count'  => '3.5k',
                'image'         => $image ? ImageHelper::getProductImage($image) : null,
            ];
        });

    /* -------------------------
       BANNER
    ------------------------- */
    $banner = Banner::where('position', 'product_detail')->first();
    $bannerImage = null;

    if ($banner && $banner->image) {
        $img = json_decode($banner->image, true);
        $bannerImage = ImageHelper::getBannerImage($img[0] ?? null);
    }

    return response()->json([
        'status'           => true,
        'banner'           => $bannerImage,
        'data'             => $product,
        'related_products' => $relatedProducts
    ]);
}


 public function product_list(Request $request)
{
    $request->validate([
        'category_id'      => 'nullable|exists:categories,id',
        'subcategory_id'   => 'nullable|exists:sub_categories,id',
        'childcategory_id' => 'nullable|exists:child_categories,id',
        'brand_id'         => 'nullable|exists:brands,id',
        'sort_by'          => 'nullable|in:low_to_high,high_to_low,1,2,3,4',
        'per_page'         => 'nullable|integer|min:1|max:100',
    ]);

    $query = Product::query()
        ->select('products.*')
        ->with([
            'variants:id,product_id,price,final_price,image,color,size,discount_type,discount_value',
            'category:id,name',
            'subCategory:id,name',
            'childCategory:id,name',
            'brand:id,name',
            'coupon:id,code,type,value,valid_until'
        ])
        ->where('products.status', 1);

    /* -------------------------
       Filters
    ------------------------- */
    if ($request->filled('category_id')) {
        $query->whereIn('products.category_id', explode(',', $request->category_id));
    }

    if ($request->filled('subcategory_id')) {
        $query->whereIn('products.subcategory_id', explode(',', $request->subcategory_id));
    }

    if ($request->filled('childcategory_id')) {
        $query->whereIn('products.child_category_id', explode(',', $request->childcategory_id));
    }

    if ($request->filled('brand_id')) {
        $query->whereIn('products.brand_id', explode(',', $request->brand_id));
    }

    /* -------------------------
       Sorting
    ------------------------- */
    if ($request->filled('sort_by')) {
        switch ($request->sort_by) {
            case 'low_to_high':
                $query->orderBy(
                    ProductVariant::select('final_price')
                        ->whereColumn('product_id', 'products.id')
                        ->orderBy('final_price', 'asc'),
                );
                break;

            case 'high_to_low':
                $query->orderBy(
                    ProductVariant::select('final_price')
                        ->whereColumn('product_id', 'products.id')
                        ->orderBy('final_price', 'desc'),
                );
                break;

            case '1': // Bestseller
            case '2': // Trending
            case '3': // Popular
            case '4': // Deal
                $query->whereJsonContains('products.product_in', (string)$request->sort_by)
                      ->latest('products.id');
                break;

            default:
                $query->latest('products.id');
        }
    } else {
        // Default sorting by product_in sequence 1, 2, 3, 4
        $query->orderByRaw("
            CASE 
                WHEN JSON_CONTAINS(products.product_in, '\"1\"') THEN 1
                WHEN JSON_CONTAINS(products.product_in, '\"2\"') THEN 2
                WHEN JSON_CONTAINS(products.product_in, '\"3\"') THEN 3
                WHEN JSON_CONTAINS(products.product_in, '\"4\"') THEN 4
                ELSE 5
            END ASC
        ")->latest('products.id');
    }

    $perPage = $request->input('per_page', 12);
    $paginator = $query->paginate($perPage);

    $products = collect($paginator->items())->map(fn ($product) =>
        $this->formatProduct($product, $request)
    );

    /* -------------------------
       SIDE DATA
    ------------------------- */

    $categories = Category::where('is_active', 1)->latest()->get();
    foreach ($categories as $cat) {
        $cat->image = ImageHelper::getCategoryImage($cat->image);
    }

    $brands = Brand::where('is_active', 1)->latest()->get();
    foreach ($brands as $brand) {
        $brand->logo = ImageHelper::getBrandImage($brand->logo);
    }

    /* -------------------------
       PRODUCT_IN GROUPS
    ------------------------- */
    $getProductIn = fn ($val) =>
        Product::where('status', 1)
            ->whereJsonContains('product_in', (string)$val)
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn ($p) => $this->formatProduct($p, $request, $val));

    return response()->json([
        'status'               => true,
        'data'                 => $products,
        'pagination'           => [
            'current_page' => $paginator->currentPage(),
            'last_page'    => $paginator->lastPage(),
            'per_page'     => $paginator->perPage(),
            'total'        => $paginator->total(),
            'next_page_url'=> $paginator->nextPageUrl(),
            'prev_page_url'=> $paginator->previousPageUrl(),
        ],
        'side_menu'            => [
            'Brands',
            'Categories',
            'Childcategories',
            'Subcategory',
            'Bestseller Product',
            'Trending Products',
            'Popular Products',
            'Ondeal Products'
        ],
        'bestseller_products'  => $getProductIn(1),
        'trending_products'    => $getProductIn(2),
        'popular_products'     => $getProductIn(3),
        'ondeal_products'      => $getProductIn(4),
        'categories'           => $categories,
        'brands'               => $brands,
    ]);
}
    private function formatProduct($product, $request, $product_in = null)
    {
        $image = null;
        $price = null;
        $original_price = null;

        // Use the first variant for default display
        $variant = $product->variants->first() ?? $product->firstVariant;

        if ($variant) {
            if ($variant->image) {
                $imageName = $this->extractImage($variant->image);
                $image = $imageName ? ImageHelper::getProductImage($imageName) : null;
            }
            $price = $variant->final_price ?? $variant->price;
            $original_price = $variant->price;
        }

        $currency = ($request->lang === 'ar')
            ? ImageHelper::getDirhamImage()
            : ImageHelper::getINRImage();

        return [
            'id'             => $product->id,
            'name'           => $product->name,
            'slug'           => $product->slug,
            'image'          => $image,
            'price'          => $price,
            'original_price' => $original_price,
            'currency'       => $currency,
            'rating'         => 4.5,
            'rating_stars'   => 5,
            'review_count'   => 128,
            'product_in'     => $product_in ?? $product->product_in,
        ];
    }

    private function extractImage($imageData)
    {
        if (str_starts_with($imageData, '[')) {
            return json_decode($imageData, true)[0] ?? null;
        }

        if (str_contains($imageData, ',')) {
            return explode(',', $imageData)[0];
        }

        return $imageData;
    }

    public function get_bestsellr_product(Request $request)
    {
            $product_in = 1;

        $bestseller_products = Product::where('status', 1)
            ->whereJsonContains('product_in', '1')
            
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatProduct($product, $request,$product_in));



        return response()->json([
            'status' => true,
            'data'   => $bestseller_products
        ]);
    }

    public function get_trending_product(Request $request)
    {
        $product_in = 2;

      $trending_products = Product::where('status', 1)
            ->whereJsonContains('product_in', '2')
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatProduct($product, $request, $product_in));
       


        return response()->json([
            'status' => true,
            'data'   => $trending_products
        ]);
    }

    public function get_popular_product(Request $request)
    {

      $product_in = 3;
        $popular_products = Product::where('status', 1)
            ->whereJsonContains('product_in', '2')
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatProduct($product, $request,$product_in));



        return response()->json([
            'status' => true,
            'data'   => $popular_products
        ]);
    }

    public function get_ondeal_product(Request $request)
    {
      $product_in = 4;

        $ondeal_products = Product::where('status', 1)
            ->whereJsonContains('product_in', '2')
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatProduct($product, $request,$product_in));



        return response()->json([
            'status' => true,
            'data'   => $ondeal_products
        ]);
    }

    
     public function footer_menu(Request $request)
    {
     $categories_menu = Category::where('is_active', 1)
    ->with([
        'subCategories' => function ($q) {
            $q->where('is_active', 1) ;
        }
    ])
    ->get();

      return response()->json([
            'status' => true,
            'data'   => $categories_menu
        ]);


    }

}
