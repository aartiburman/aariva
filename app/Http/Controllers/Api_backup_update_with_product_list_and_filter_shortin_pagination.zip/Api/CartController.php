<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Product;
use App\Helpers\ImageHelper;
use App\Helpers\PriceHelper;
use App\Models\Banner;
use Carbon\Carbon;
use App\Models\Coupon;



class CartController extends Controller
{

    public function get_cart_detail(Request $request)
    {
        $request->validate([
            'user_id'  => 'required|exists:users,id',
            'per_page' => 'nullable|integer|min:1|max:100',
        ]);

        $perPage = $request->input('per_page', 12);

        $paginator = Cart::where('user_id', $request->user_id)
            ->leftJoin('products', 'carts.product_id', '=', 'products.id')
            ->select('carts.*', 'products.name as product_name', 'products.slug as product_slug', 'products.short_description')
            ->paginate($perPage);

        foreach ($paginator->items() as $item) {
            $item->image = ImageHelper::getProductImage($item->image);
        }

        $banner = Banner::where('position', 'cart')->first();
        $bannerImage = null;
        if ($banner) {
            $img = json_decode($banner->image ?? '', true);
            $bannerImage = ImageHelper::getBannerImage($img[0] ?? '');
        }

        return response()->json([
            'status'     => true,
            'breadcrumb' => [
                'image' => $bannerImage
            ],
           'count'   => $paginator->total(),
            'data'             => $paginator->items(),
            'related_products' => [],
             'pagination' => [
                'current_page'  => $paginator->currentPage(),
                'last_page'     => $paginator->lastPage(),
                'per_page'      => $paginator->perPage(),
                'total'         => $paginator->total(),
                'next_page_url' => $paginator->nextPageUrl(),
                'prev_page_url' => $paginator->previousPageUrl(),
            ],
        ]);
    }


    public function add_remove_cart(Request $request)
    {
        $request->validate([
            'user_id'    => 'required|exists:users,id',
            'product_id' => 'required|exists:products,id',
            'qty'        => 'required|numeric|min:1',
            'action'     => 'required|in:0,1',
        ]);

        /* -------------------------
        Fetch Product with first variant & coupon
        ------------------------- */
        $product = Product::with([
            'variants',
            'coupon'
        ])->find($request->product_id);

        if (!$product || $product->variants->isEmpty()) {
            return response()->json([
                'status'  => false,
                'message' => 'Product or variant not found'
            ], 404);
        }

        $variant = $product->variants->first();

        /* -------------------------
        Variant Base Price
        ------------------------- */
        $price = PriceHelper::applyDiscount(
            $variant->price,
            $variant->discount_type,
            $variant->discount_value
        );

        /* -------------------------
        Apply Coupon (if valid)
        ------------------------- */
        $today = Carbon::now();

        if (
            $product->coupon &&
            $product->coupon->status == 1 &&
            $product->coupon->valid_from <= $today &&
            $product->coupon->valid_until >= $today &&
            (
                is_null($product->coupon->max_uses) ||
                $product->coupon->used_count < $product->coupon->max_uses
            )
        ) {
            $price = PriceHelper::applyDiscount(
                $price,
                $product->coupon->type,
                $product->coupon->value
            );
        }

        /* -------------------------
        First Variant Image
        ------------------------- */
        $image = null;
        if (!empty($variant->image)) {
            if (str_starts_with($variant->image, '[')) {
                $imgs  = json_decode($variant->image, true);
                $image = ImageHelper::getProductImage($imgs[0] ?? null);
                $img = $imgs[0] ?? null;
            } elseif (str_contains($variant->image, ',')) {
                $imgs  = explode(',', $variant->image);
                $image = ImageHelper::getProductImage(trim($imgs[0]));
                $img = $imgs[0] ?? null;
            } else {
                $image = ImageHelper::getProductImage($variant->image);
                $img = $variant->image ?? null;
            }
        }

        /* -------------------------
        ADD TO CART
        ------------------------- */
        if ($request->action == 1) {

            Cart::updateOrCreate(
                [
                    'user_id'    => $request->user_id,
                    'product_id' => $product->id,
                    'variant_id' => $variant->id,
                ],
                [
                    'qty'      => $request->qty,
                    'color'    => $request->color ?? $variant->color ?? null,
                    'size'     => $request->size ?? null,
                    'price'    => $price,
                    'discount' => $variant->discount_value ?? 0,
                    'image'    => $img,
                ]
            );

            return response()->json([
                'status'  => true,
                'message' => 'Item added to cart successfully'
            ]);
        }

        /* -------------------------
        REMOVE FROM CART
        ------------------------- */
        Cart::where('user_id', $request->user_id)
            ->where('product_id', $product->id)
            ->where('variant_id', $variant->id)
            ->delete();

        return response()->json([
            'status'  => true,
            'message' => 'Item removed from cart successfully'
        ]);
    }


    private function formatProduct($product, $request)
    {
        $image = null;
        $price = null;

        if ($product->firstVariant && $product->firstVariant->image) {
            $imageName = $this->extractImage($product->firstVariant->image);
            $image = $imageName ? ImageHelper::getProductImage($imageName) : null;
            $price = $product->firstVariant->price;
        }

        $currency = ($request->lang === 'ar')
            ? ImageHelper::getDirhamImage()
            : ImageHelper::getINRImage();

        return [
            'id'            => $product->id,
            'name'          => $product->name,
            'slug'          => $product->slug,
            'image'         => $image,
            'price'         => $price,
            'currency'      => $currency,
            'rating'        => 4.5,
            'rating_stars'  => 5,
            'review_count'  => 128,
        ];
    }

    private function extractImage($imageData)
    {
        if (str_starts_with($imageData, '[')) {
            return json_decode($imageData, true)[0] ?? null;
        }

        if (str_contains($imageData, ',')) {
            return explode(',', $imageData)[0];
        }

        return $imageData;
    }

}
