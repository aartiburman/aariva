<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Product;
use App\Models\Category;
use App\Models\SubCategory;
use App\Models\ChildCategory;
use App\Models\Brand;
use App\Helpers\ImageHelper;
use App\Helpers\PriceHelper;
use App\Models\Banner;
use Carbon\Carbon;
use App\Models\Coupon;
use Stichoza\GoogleTranslate\GoogleTranslate;


class UserCommonController extends Controller
{
    public function get_categories(Request $request)
    {
        $categories = Category::where('is_active', 1)
            ->orderBy('id', 'DESC')
            ->get();

        foreach ($categories as $category) {
            $category->image = ImageHelper::getCategoryImage($category->image);
        }

        return response()->json([
            'status' => true,
            'data'   => $categories
        ], 200);
    }


    public function get_subcategories(Request $request)
    {
        $locale = app()->getLocale(); // ar, np, en, etc.
        $translator = new GoogleTranslate($locale);

        $subcategories = SubCategory::where('sub_categories.is_active', 1)
            ->leftJoin('categories', 'sub_categories.category_id', '=', 'categories.id')
            ->select(
                'sub_categories.*',
                'categories.name as category_name'
            )
            ->orderBy('sub_categories.id', 'DESC')
            ->get();

        foreach ($subcategories as $subcategory) {

            /* -------------------------
           IMAGE
        ------------------------- */
            $subcategory->image = ImageHelper::getSubCategoryImage($subcategory->image);

            /* -------------------------
           TRANSLATION (ONLY IF ar / np)
        ------------------------- */
            if (in_array($locale, ['ar', 'np'])) {
                $subcategory->name = $translator->translate($subcategory->name);

                if (!empty($subcategory->description)) {
                    $subcategory->description = $translator->translate($subcategory->description);
                }

                if (!empty($subcategory->category_name)) {
                    $subcategory->category_name = $translator->translate($subcategory->category_name);
                }
            }
        }

        return response()->json([
            'status' => true,
            'lang'   => $locale,
            'data'   => $subcategories
        ], 200);
    }

    public function get_childcategories(Request $request)
    {
        $childcategories = ChildCategory::where('is_active', 1)
            ->orderBy('id', 'DESC')
            ->get();

        return response()->json([
            'status' => true,
            'data'   => $childcategories
        ], 200);
    }

    
    public function get_brands(Request $request)
    {
        $brands = Brand::select('*')->orderBy('id','DESC')->get();

        foreach ($brands as $key => $value) {
            $value->logo = ImageHelper::getBrandImage($value->logo);
        }

        return response()->json([
            'status' => true,
            'data'   => $brands
        ], 200);
    }
}
