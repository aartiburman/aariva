<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Helpers\ImageHelper;
use App\Models\Product;
use Illuminate\Support\Facades\Lang;

class UserController extends Controller
{
    public function signUp(Request $request)
    {
        $inputs = $request->all();
        $rules = [
            'name'           => 'required',
            'email_or_phone' => 'required',
            'password'       => 'required',
        ];

        $validator = Validator::make($inputs, $rules);
        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            return response(['status' => false, 'message' => $errors[0]], 200);
        }

        $User = new User;
        $User->uqid = 'USER-' . strtoupper(uniqid());
        $User->role =  '3';
        $User->name = $inputs['name'];

        $email_or_phone = $inputs['email_or_phone'];
        if (filter_var($email_or_phone, FILTER_VALIDATE_EMAIL)) {
            if (User::where('email', $email_or_phone)->exists()) {
                return response(['status' => false, 'message' => 'Email already registered'], 200);
            }
            $User->email = $email_or_phone??'';
        } else {
           
            if (User::where('phone', $email_or_phone)->exists()) {
                return response(['status' => false, 'message' => 'Mobile number already registered'], 200);
            }
            $User->phone = $email_or_phone??'';
        }

        //  echo '<pre>';
        // print_r($email_or_phone); 
        // die;

 
        $User->password = Hash::make($inputs['password']);
        if (!empty($inputs['device_type'])) {
            $User->device_type = $inputs['device_type'];
        }
        if (!empty($inputs['device_token'])) {
            $User->device_token = $inputs['device_token'];
        }
       
        $User->save();
        if ($User) {
            return response(['status' => true, 'message' => 'registration_success',  'data' => $User]);
        } else {
            return response(['status' => false, 'message' => 'registration_error']);
        }
    }


  
    public function userlogin(Request $request)
    {
        $inputs = $request->all();
        $rules = [
            'email_or_phone' => 'required',
            'password'       => 'required',
        ];

        $validator = Validator::make($inputs, $rules);
        if ($validator->fails()) {
            $errors = $validator->errors()->all();
            return response(['status' => false, 'message' => $errors[0]], 200);
        }

        $email_or_phone = $inputs['email_or_phone'];
        $password = $inputs['password'];

        if (filter_var($email_or_phone, FILTER_VALIDATE_EMAIL)) {
            $user = User::where('email', $email_or_phone)->first();
        }else{
            $user = User::where('phone', $email_or_phone)->first();
        }

        if (!$user) {
            return response(['status' => false, 'message' => 'user_not_found'], 200);
        }

        if (!Hash::check($password, $user->password)) {
            return response(['status' => false, 'message' => 'incorrect_password'], 200);
        }   
        $device_token = $inputs['device_token']??'';
        if (!empty($device_token)) {
            $user->device_token = $device_token;

            $user->save();
        }

        $user->lang = $inputs['lang']??'en';
        $token = $user->createToken('auth_token')->plainTextToken;
        return response(['status' => true, 'message' => 'login_success', 'token' => $token, 'data' => $user]);   

    }

    public function logout(Request $request)
    {
        // $user = $request->user();
        $inputs = $request->all();
        $user = $inputs['user_id'] ?? null;
        if ($user) {
            User::where('id', $user)->update(['device_token' => null]);
        }
        return response()->json([
            'status' => true,
            'message' => 'logout_success'
        ]);
    }
    

}

