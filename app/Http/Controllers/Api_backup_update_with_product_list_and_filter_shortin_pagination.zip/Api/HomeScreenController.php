<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Helpers\ImageHelper;
use App\Models\Product;
use Illuminate\Support\Facades\Lang;


class HomeScreenController extends Controller
{
     public function home(Request $request)
    {
        /* =========================
     * MENU CATEGORIES
     * ========================= */
       $categories_menu = Category::where('is_active', 1)
    ->with([
        'subCategories' => function ($q) {
            $q->where('is_active', 1)
              ->with([
                  'childCategories' => function ($q2) {
                      $q2->where('is_active', 1);
                  }
              ]);
        }
    ])
    ->get();


    

        /* =========================
     * HERO BANNERS
     * ========================= */
        $hero_banner = Banner::where('status', 1)
            ->where('position', 'top')
            ->get();

        foreach ($hero_banner as $banner) {
            $images = json_decode($banner->image, true) ?? [];
            $banner->image = array_map(
                fn($img) => ImageHelper::getBannerImage($img),
                $images
            );
        }

        /* =========================
     * DEAL BANNERS (FIXED)
     * ========================= */
        $deal_banner = Banner::where('status', 1)
            ->where('position', 'deal')
            ->get();

        foreach ($deal_banner as $banner) {
            $images = json_decode($banner->image, true) ?? [];
            $banner->image = array_map(
                fn($img) => ImageHelper::getBannerImage($img),
                $images
            );
        }

        /* =========================
     * CATEGORY LIST
     * ========================= */
        $categories = Category::where('is_active', 1)->get();
        foreach ($categories as $category) {
            $category->image = ImageHelper::getCategoryImage($category->image);
        }

        /* =========================
     * DEAL PRODUCTS
     * ========================= */
        $deal_products = Product::where('status', 1)
            ->whereJsonContains('product_in', '2')
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatProduct($product, $request));

        /* =========================
     * NORMAL PRODUCTS
     * ========================= */
        $products = Product::where('status', 1)
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatProduct($product, $request));

        /* =========================
     * LOWEST PRICE PRODUCTS
     * ========================= */
        $lowestpriceproducts = Product::where('status', 1)
            ->with('lowestPriceVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatLowestPriceProduct($product, $request));

        /* =========================
     * TRENDING PRODUCTS
     * ========================= */
        $tranding_products = Product::where('status', 1)
            ->whereJsonContains('product_in', '2')
            ->with('firstVariant:id,product_id,price,image')
            ->limit(15)
            ->get()
            ->map(fn($product) => $this->formatProduct($product, $request));

             /* =========================
     * Bottom  banner
     * ========================= */
        $bottom_banner = Banner::where('status', 1)
            ->where('position', 'middle')
            ->get();

        foreach ($bottom_banner as $banner) {
            $images = json_decode($banner->image, true) ?? [];
            $banner->image = array_map(
                fn($img) => ImageHelper::getBannerImage($img),
                $images
            );
        }

        /* =========================
     * CATEGORY RESPONSE
     * ========================= */
        $category_product = Category::select(
            'id',
            'name',
            'slug',
            // 'image'
        )
            ->where('is_active', 1)
            ->with([
                'subCategories' => function ($q) {
                    $q->select(
                        'id',
                        'category_id',
                        'name',
                        'slug',
                        'image'
                    )
                        ->where('is_active', 1);
                }
            ])
            ->get();


        $category_product = $category_product->map(function ($category) {

        
            // SubCategory images
            foreach ($category->subCategories as $sub) {
                $sub->image = $sub->image
                    ? ImageHelper::getSubCategoryImage($sub->image)
                    : null;
            }

            return $category;
        });



        /* =========================
     * FINAL RESPONSE
     * ========================= */
        return response()->json([
            'status'              => true,
            'message'             => 'home_api',
            'menu'                => $categories_menu,
            'hero_banner'         => $hero_banner,
            'deal_banner'         => $deal_banner,
            'deal_products'       => $deal_products,
            'categories'          => $categories,
            'products'            => $products,
            'lowestpriceproducts' => $lowestpriceproducts,
            'tranding_products'   => $tranding_products,
            'bottom_banner'       => $bottom_banner,
            'category_product'       => $category_product,
        ]);
    }

    private function formatProduct($product, $request)
    {
        $image = null;
        $price = null;

        if ($product->firstVariant && $product->firstVariant->image) {
            $imageName = $this->extractImage($product->firstVariant->image);
            $image = $imageName ? ImageHelper::getProductImage($imageName) : null;
            $price = $product->firstVariant->price;
        }

        $currency = ($request->lang === 'ar')
            ? ImageHelper::getDirhamImage()
            : ImageHelper::getINRImage();

        return [
            'id'            => $product->id,
            'name'          => $product->name,
            'slug'          => $product->slug,
            'image'         => $image,
            'price'         => $price,
            'currency'      => $currency,
            'rating'        => 4.5,
            'rating_stars'  => 5,
            'review_count'  => 128,
        ];
    }

    private function extractImage($imageData)
    {
        if (str_starts_with($imageData, '[')) {
            return json_decode($imageData, true)[0] ?? null;
        }

        if (str_contains($imageData, ',')) {
            return explode(',', $imageData)[0];
        }

        return $imageData;
    }

    private function formatLowestPriceProduct($product, $request)
    {
        $image = null;
        $price = null;

        if ($product->lowestPriceVariant && $product->lowestPriceVariant->image) {
            $imageName = $this->extractImage($product->lowestPriceVariant->image);
            $image = $imageName ? ImageHelper::getProductImage($imageName) : null;
            $price = $product->lowestPriceVariant->price;
        }

        $currency = ($request->lang === 'ar')
            ? ImageHelper::getDirhamImage()
            : ImageHelper::getINRImage();

        return [
            'id'            => $product->id,
            'name'          => $product->name,
            'slug'          => $product->slug,
            'image'         => $image,
            'price'         => $price,
            'currency'      => $currency,
            'rating'        => 4.5,
            'rating_stars'  => 5,
            'review_count'  => 128,
        ];
    }
}
